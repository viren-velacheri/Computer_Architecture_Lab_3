#include "my_mem.h"
#include <stdlib.h>
#include <stdio.h>


/*
* You CAN'T allocate a global array of memory nodes in static memory, for example,
* you CAN'T do node[50], you HAVE to use pointers (linked lists). You may
* need more than one linked list, although one is enough to keep/maintain information about all
* memory ranges
*
* Feel free to use a different data structure, single/doubly linked lists, trees, etc if you think they're better.
*
* Also, to make sure you do it correctly; all structures that you use for bookkeeping (aka the list), you will use
* the system's malloc, not yours. Only user's data will reside in the heap you are managing.
*/

//example: head of a list of nodes
MRNode* head;
// constant for returning value of zero when not enough deallocated MEMORY
// available for requested size. Did this so 0 isn't a magic number.
#define NOT_ENOUGH_MEMORY 0
// constant for representing when a node is free.
#define FREE 0
// constant for representing when a node is occupied/allocated.
#define ALLOCATED 1


//This is your "heap", a.k.a. the memory range you will manage. Imagine
//this is actually the entire RAM of a computer, and you are the OS
//managing memory requests from applications, but in a MUCH simpler
//and constrained scenario.
//Uou will reserve/allocate and manage memory from this block.
//If you run out of memory or can't allocate any more, you should "throw" a
//segmentation fault (your turn to get back at all segfaults that
//bothered you) and exit the program with an error (there's an example below)
//You won't need to extend/increase this heap.
//Note: In real OS, what happens when you do allocate more than what you have?
//      well, run "man sbrk" on your terminal, you'll learn how to use it in the OS class
byte_ptr heap;

//just a toggle flag to initialize only once
static char mm_inited = 0;

/* Initialized the state of the memory manager. We allocate HEAP_SIZE
* bytes to be our block, and then you initialize your variables; for example
*  set your list head to an initial big and empty range.
*/
void my_mminit()
{
  heap = (byte_ptr) malloc (HEAP_SIZE);
  if (heap == 0) {
    printf("ERROR during mm init malloc\n");
    exit(1);
  }
  mm_inited = 1;

  //TODO: initialize your data structure(s) here
  //for example, we can initialize a MRNode with the entire memory

  //allocate a new list node
  head = malloc(sizeof(MRNode));
  //set it to the len of entire memory
  head->length = HEAP_SIZE;
  //this range starts at the start of the heap
  head->offset = heap;
  //set isUsed to 0 to indicate head is initially free.
  head->isUsed = FREE;
}

//you shouldn't need to change this, but feel free to do so if you want
//it's just a switch to choose allocation policy during compile time
//and an init that only runs once
void* mm_malloc(size_t size)
{
  if (!mm_inited)
  my_mminit();

  #ifdef BESTFIT
  return mm_best_fit_malloc(size);
  #elif FIRSTFIT
  return mm_first_fit_malloc(size);
  #else
  printf("memory system policy undefined\n");
  exit(1);
  #endif
}

/*
*
* This is where you will write your code.
*
*/

/* This method finds the smallest possible unallocated space in memory that can
fit the given size. If there is no spot big enough for the size,all memory
is allocated, or the requested size is too big (bigger than heap size), zero
is returned. Otherwise, we return a pointer to the space where the memory
was allocated. */
void* mm_best_fit_malloc (size_t size)
{
  //TODO: .. some code ..
  //again, to make sure you do this correctly, if you need to allocate some node in a linked list or whatever
  //structure you use, use malloc, eg., MRNode* n = malloc(sizeof(Node))

  //return a pointer to some address in the allocated 32MB heap, for example, the first time someone
  //calls mm_malloc, you will likely: "return heap+HEAP_SIZE-size", because there's only one free block in the heap (the
  //entire heap) and you're returning a pointer to the rightmost 'size' bytes of the heap that the user can then use
  //however it wants, the same way one can use malloc

  //your return value HAS TO BE a pointer inside the heap: [heap, heap+size)


  /*******************************
  ******  THE MALLOC BELOW IS JUST A PLACEHOLDER SO THAT main CAN RUN.
  ******  YOUR TASK IS TO RESERVE MEMORY FROM byte_ptr heap; AND ONLY USE
  ******  malloc FOR METADATA LIKE LISTS, ETC. YOU SHOULD DEFINITELY DELETE
  ******  THIS LINE WHEN YOU'RE DOING THIS LAB
  *******************************/
  //return malloc(size); Just for running lab.
  //If the size requested is greater than HEAP_SIZE, then immediately exit by
  // returning zero. Don't want to waste time going in loop below.
  if(size > HEAP_SIZE) {
    return NOT_ENOUGH_MEMORY;
  }
  MRNode* currNode = head; //starting node for loop
  // the below variable stores the bestNode or the one that is bestfit for
  // given size requested. Updated in while loop.
  MRNode* bestNode = malloc(sizeof(MRNode));
  // length initially set to -1 so that for first node that we come across
  // that can fit size requested, the change is easy and there is no confusion.
  // If at end of the traversal, length of bestNode is still at -1, then that
  // means that either all nodes were allocated or the size requested was too
  // big. Hence, we return 0.
  // The below variable represents when no node is found that can hold
  // requested size by user.
  const int NOT_FOUND = -1;
  bestNode->length = NOT_FOUND;
  while(currNode != NULL) {
    if(currNode->isUsed == FREE) {
      // since perfect fit, no need to go on. Can simply change state of this
      // node to used and then return a pointer to this node.
      if(currNode->length == size) {
        currNode->isUsed = ALLOCATED;
        return currNode->offset;
      } else if(currNode->length > size) {
        // This is where we check whether there is a "new" bestfit node.
        if(bestNode->length == NOT_FOUND || currNode->length < bestNode->length) {
          bestNode = currNode;
        }
      }
    }
    currNode = currNode->next; // the usual update.
  }
  //The check described above done outside while loop.
  if(bestNode->length == NOT_FOUND) {
    return NOT_ENOUGH_MEMORY;
  }
  // If didn't return zero, that means we did find at least one node that could
  // fit the requested size and even if there were multiple, we found the best
  // one.
  MRNode* allocatedNode = malloc(sizeof(MRNode)); //creation of the new node.
  add_nodes(bestNode, allocatedNode, size);
  return allocatedNode->offset;
}

/* This method finds the first free/unallocated space in memory that can fit
the requested size in memory. If none can be found, zero is returned.
Otherwise a pointer to the first spot that can hold the requested size is
returned. */
void* mm_first_fit_malloc (size_t size)
{
  /*
  *   TODO: Your code here
  */
  // Similar to above method where if requested size is greater than the
  // HEAP_SIZE or whole memory, then just return zero so we don't have to waste
  // time going in loop.
  if(size > HEAP_SIZE) {
    return NOT_ENOUGH_MEMORY;
  }
  MRNode* currNode = head;
  // Start are loop from head. Then whenever we come across any node that is
  // free or not being used, then we check its size. If it is a perfect fit,
  // just set state of that spot to allocated and return pointer to that node.
  // Otherwise if length of node is greater than size, we do the exact thing
  // we did above with best fit in terms of allocating and creating the new
  // node and then returning a pointer to it.If none of this, in other words
  // node was allocated or it didn't meet the requested size, simply go to
  // next node or space in memory. At the end if we haven't returned by now
  // that means either the size requested was too large for any one unallocated
  // space or all the nodes were allocated. In either case, 0 is returned.
  while(currNode != NULL) {
    if(currNode->isUsed == FREE) {
      if(currNode->length == size) {
        currNode->isUsed = ALLOCATED;
        return currNode->offset;
      } else if(currNode->length > size) {
        MRNode* allocatedNode = malloc(sizeof(MRNode));
        add_nodes(currNode, allocatedNode, size);
        return allocatedNode->offset;
      }
    }
    currNode = currNode->next;
  }
  return NOT_ENOUGH_MEMORY;
  /*******************************
  ******  THE MALLOC BELOW IS JUST A PLACEHOLDER SO THAT main CAN RUN.
  ******  YOUR TASK IS TO RESERVE MEMORY FROM byte_ptr heap; AND ONLY USE
  ******  malloc FOR METADATA LIKE LISTS, ETC. YOU SHOULD DEFINITELY DELETE
  ******  THIS LINE WHEN YOU'RE DOING THIS LAB
  *******************************/
}

/* This method frees a node whose offset is at ptr. If no such node is found,
then segmentation fault is returned. That or if ptr is at starting byte or
is null or is already found to be unallocated, segmentation fault is
returned. If located and everything is legal, we unallocate space and then
any free space on either side if unallocated is merged with this node.*/
void mm_free(void* ptr)
{
  //your work here
  //you have to mark the region that starts at ptr as free
  //and possibly merge buffers on the left or the right of it

  //if ptr is invalid (does not point to the start
  //of a memory block you allocated, emulate a SEGFAULT:
  if (ptr == 0) {
    printf("Segmentation fault.\n");
    exit(1);
  }
  MRNode* currNode = head;
  // makes it easier to do remove in a double link list manner.
  MRNode* trailer = NULL;
  MRNode* trailer_trailer = NULL;
  // This loop is for trying to find node that is ptr by checking offsets.
  while(currNode != NULL && currNode->offset != ptr) {
    trailer_trailer = trailer;
    trailer = currNode;
    currNode = currNode->next;
  }
  // If none found or the node is already free, segmentation fault
  // occurs and that is returned.
  if(currNode->offset != ptr || currNode->isUsed == FREE) {
    printf("Segmentation fault.\n");
    exit(1);
  }
  currNode->isUsed = FREE; // set allocated node to unallocated.
  MRNode* nextNode = currNode->next; // get next node
  // If the right node is not null and it is free, the merge occurs and then
  // we free the node.
  if(nextNode != NULL && nextNode->isUsed == FREE) {
    currNode->length += nextNode->length;
    currNode->next = nextNode->next;
    free((void*)nextNode);
  }
  // This is the check for left space or the node previous to the node where
  // ptr is. If it is not null and is free, this left node is merged.
  // The first if is for the special case where if the head is the node to be
  // removed then we simply set head to be the newNext or the node after the
  // old head. Otherwise,just use trail of trailer to remove with ease.
  // At the end, free the node to remove.
  if(trailer != NULL && trailer->isUsed == FREE) {
    currNode->length += trailer->length;
    currNode->offset = trailer->offset;
    if(trailer == head) {
      head = currNode;
    } else {
      trailer_trailer->next = currNode;
    }
    free((void*)trailer);
  }
}

//this is the function that will be used to grade you, make sure to print in the
//correct format according to the pdf.
void mm_print_heap_status(FILE* fout)
{
  MRNode* currNode = head;
  // This is a classic fencepost problem where we put the first n-1 items in a
  // loop like fashion and then print last one at end to avoid the extra space
  // that would come if we looped through everything. That's why we go through
  // until last element and then print out last element without space. F is
  // printed for free/unallocated space, A is printed for allocated space.
  // Pretty straightforward.
  // Note: I didn't make F and A constants because when I did I got warnings
  // so didn't want to make
  char *isAllocatedChar;
  while(currNode->next != NULL) {
    if(currNode->isUsed == FREE) {
      isAllocatedChar = "F"; // F stands for a space in memory that is free.
    } else {
      isAllocatedChar = "A"; //A stands to an occupied space in memory.
    }
    fprintf(fout, "%d%s ", currNode->length, isAllocatedChar);
    currNode= currNode->next;
  }
  if(currNode != NULL) {
    if(currNode->isUsed == FREE) {
      isAllocatedChar = "F";
    } else {
      isAllocatedChar = "A";
    }
    fprintf(fout, "%d%s\n", currNode->length, isAllocatedChar);
  }
  /*
  *   Your code here. Because you are writing a file or maybe stdout (your terminal), instead of using printf, use fprintf
  *   It has the exact same syntax, but the first parameter is fout. This function assumes the file already exists.
  *   Check test.c if you want to see how this works. You shouldn't worry about it, just use fprintf as the example below.
  *   eg: fprintf(fout, "some string %d  %s\n", parameter1, parameter2)
  */
}

/* This method is for pushing all and merging the total unallocated space
(if there are nodes that are unallocated) as the first space followed by all
the allocated nodes/spaces in memory. */
void  mm_defragment()
{
  // The below node is the new head that might be needed.
  MRNode* possibleHead = malloc(sizeof(MRNode));
  // the starting node is set to possible head
  MRNode* currNode = possibleHead;
  // same with trailer.
  MRNode* trailer = possibleHead;
  // This is the temporary node used to storing nodes temporarily to better
  // ease the removal and freeing of nodes more easily.
  MRNode* temp = malloc(sizeof(MRNode));
  // This first if checks the case where head is allocated.Also do a check on
  // size to make sure that unallocated spaces do exist. The next if checks
  // when the head itself is unallocated and in this we simply merge the other
  // free spaces to the head and free those respective nodes as well. If neither
  // works, something is wrong and segmentation fault is given and we exit.
  if(head->length < HEAP_SIZE && head->isUsed == ALLOCATED) {
    // the below three lines set up where the new head is set and then we
    // go one past this new head to original head to begin traversal.
    possibleHead->next = head;
    head = possibleHead;
    currNode = currNode->next;
  }
  // in this loop, until we reach end, any free unallocated space or node
  // that we find, we add that/merge that to the head. We then use temporary
  // for storing node to be removed or free before removing it.
  currNode = head->next;
  while(currNode != NULL) {
    if(currNode->isUsed == FREE) {
      head->length += currNode->length;
      trailer->next = currNode->next;
      temp = currNode;
      currNode = currNode->next;
      free((void*)temp);
    } else {
      trailer = currNode;
      currNode = currNode->next;
    }
  }
  /*
  * Push all occupied blocks to the right, and make one big free block on the left.
  */
}

//Creating linked list functionalities in functions is a good idea
//e.g.  void add_node(Node* head, Node* new_node)
//if you do, declare those on the my_mem.h header file and put their code here.

// This helper method is used for adding the newNode with size in both
// bestfit and firstfit method. Created this to reduce/eliminate repetition
// that would otherwise be there.
void add_nodes(MRNode* currNode, MRNode* newNode, size_t newNodeSize) {
  currNode->length -= newNodeSize;
  newNode->length = newNodeSize;
  // This is how the offset is calculated.
  newNode->offset = currNode->offset + currNode->length;
  newNode->isUsed = ALLOCATED;
  newNode->next = currNode->next;
  currNode->next = newNode;
}
