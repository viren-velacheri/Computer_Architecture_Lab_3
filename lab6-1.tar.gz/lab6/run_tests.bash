#!/bin/bash

# Loop through all the files in the traces directory
for filename in traces/*.rep; do
	# Print out which trace file we're on
	echo "Trace: $filename"
	# Print out header for first fit
	echo "Firstfit:"
	# Run the first fit tests
	./test_firstfit "$filename" normal
	./test_firstfit "$filename" defrag
	#Print out header for best fit
	echo "Bestfit:"
	# Run the best fit tests
	./test_bestfit "$filename" normal
	./test_bestfit "$filename" defrag
done
