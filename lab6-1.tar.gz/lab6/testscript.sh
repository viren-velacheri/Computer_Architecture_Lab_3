make clean; make
echo "Testing test_bestfit"
for i in ./traces/*; do
    echo $i normal 
    ./test_bestfit $i normal
    echo $i defrag
    ./test_bestfit $i defrag
done
echo "Testing test_firstfit"
for i in ./traces/*; do
    echo $i normal
    ./test_firstfit $i normal
    echo $i defrag
    ./test_firstfit $i defrag
done
